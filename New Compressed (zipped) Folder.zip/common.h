#pragma once


#include <windows.h>



#include "iosys.h"
#include "stdpipe.h"
#include "string_data.h"
#include "tool_functions.h"
#include "tool_dispatch.h"
#include "numbers.h"
#include "string_tools.h"



