#pragma once

extern "C" {
	extern bool IsSpace(int c);
	extern bool IsDigit(int c);
}
