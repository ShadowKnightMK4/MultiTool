#pragma once
extern "C" {
	/*
	* What this is is a loose fitting wrapper around a char* string that takes care of reallocs so the user don't have too.
	*
	* There's 2 main components
	*
	* The LWAnsiString struct which houses the struct tracking allocation size, current len of the string and the pointer to the string data. It'll also hold a pointer to an AllocationHandler string (below).
	*
	*
	* The AllocationHandler struct which is a set of function pointers that default to small stubs that call the Windows Heap routines on top of the current process heap. Why?
	* this will let us customize how data is allocated, maybe sub in a different heap plan or more. The default routines will ask the Heap to trigger exceptions and zero memory on allocaiton.
	*
	* the inpact is we get a functional low level string type built on raw Windows API that lets use inject *how* to allocate memory and how to free it WITHOUT libc or the normal C++ stuff.
	* Suitable for when one wants small footprint and no dependencies on C++ or libc.  This is a C style string type that can be used in C++ code.
	*
	*
	* If You want to Inject a custom Allocation Handler use the Ex routines such as  LWAnsiString* CreateLWAnsiStringFromStringEx(AllocationHandler* x, const char* str);
	*/
#ifndef LWANSISTRING_H
#define LWANSISTRING_H
#include <Windows.h>
	/// <summary>
	/// See MSDN HeapAlloc for an idea of what do implementation for this.
	/// </summary>
	typedef void* (WINAPI* MyAlloc)(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes);
	/// <summary>
	/// See MSDN HeapCreate for an idea of what do implementation for this WITH ONE VERY IMPORTANT EXCEPTION, receiving (0,0,0) should be equivalent to GetProcessHeap() and return the current process heap desired
	/// </summary>
	typedef HANDLE(WINAPI* MyHeapGet)(DWORD Options, SIZE_T Start, SIZE_T Cap);

	/// <summary>
	/// See MSDN HeapFree for an idea of what do implementation for this.
	/// </summary>
	typedef BOOL(WINAPI* MyHeapFree)(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem);

	/// <summary>
	/// See MSDN HeapReAlloc for an idea of what do implementation for this.
	/// </summary>
	typedef LPVOID(WINAPI* MyHeapReAlloc)(
		HANDLE                 hHeap,
		DWORD                  dwFlags,
		LPVOID lpMem,
		SIZE_T                 dwBytes
		);

	typedef struct LWAnsiString
	{
		// the string data. // This is a pointer to the actual string data. It is allocated on the heap. The PTR Should't be changed but the string data is fine to
		char* Data;
		// the length of the string. Keep in mind while you can change the contents of the string, you should not change this value.
		int Length;
		// the allocated size of the string
		int AllocatedSize;
		/// <summary>
		/// is the heap we allocated from. You coulnd't mod this either.
		/// </summary>
		void* AllocatedHandle;
	} LWAnsiString;

	struct AllocationHandler
	{
		MyAlloc CustomFirstAlloc;
		MyHeapGet CustomGetHeap;
		MyHeapFree CustomFree;
		MyHeapReAlloc CustomReAlloc;
	};

	// LWAnsiString.cpp : Defines the functions for the static library.
	//

	/*
	* Our game plan is put all the strings we create and grow into single heap, created on first alloc.
	*/
#include "pch.h"
#include "framework.h"

	/// <summary>
	/// Trigger a realloc if needed to ensure the string has at least new_size characters available. If the string is null, it will return null. If new_size is less than or equal to the current size, it will return the string unchanged. Also allocated extra memory will zero it out
	/// </summary>
	/// <param name="str"></param>
	/// <param name="new_size"></param>
	/// <returns></returns>
	/// <remarks>IMPORTANT. As it stands atm, this does NOT zero stuff out.</remarks>
	LWAnsiString* LWAnsiString_Reserve(LWAnsiString* str, int new_size);

	/// <summary>
	/// While the memory adjusting strings clamp, this will let you do that in a single call
	/// </summary>
	/// <param name="str">string to clamp</param>
	void LWAnsiString_ClampNull(LWAnsiString* str);

	/// <summary>
	/// Create an ansi string type of able to hold len characters including the null terminater at the end aka. pass 25 , get 26
	/// </summary>
	/// <param name="len">length to do</param>
	/// <returns>pointer to new string. </returns>
	LWAnsiString* LWAnsiString_CreateString(int len);

	LWAnsiString* LWAnsiString_CreateStringEx(AllocationHandler* x, int len);
	/// <summary>
	/// Create a string to hold the c string
	/// </summary>
	/// <param name="str">starting value of the string.</param>
	/// <returns>pointer to new string. </returns>
	LWAnsiString* LWAnsiString_CreateFromString(const char* str);

	/// <summary>
	/// Create a string to hold the c string and specify a different allocator 
	/// </summary>
	/// <param name="x">replacement allocator. </param>
	/// <param name="str">starting value of the string.</param>
	/// <returns>pointer to new string. </returns>
	LWAnsiString* LWAnsiString_CreateFromStringEx(AllocationHandler* x, const char* str);
	/// <summary>
	/// free our string data we prev allocated. If there is some corruption or the string is null, this will return false but will attempt to free as much as possible.
	/// </summary>
	/// <param name="str">string to free</param>
	/// <returns>true if fully freed. false if something wasn't</returns>
	/// <remarks>depends on the AllocateHandle agnostic pointer being a valid AllocaitonHandle. That incorrect? then fail.     Otherwise if buffer is null, we don't free it. if the struct is null. we don't free it. If ths allocator is not the default, we free it</remarks>
	bool LWAnsiString_FreeString(LWAnsiString* str);


	/// <summary>
	/// how long is this string?
	/// </summary>
	/// <param name="str"></param>
	/// <returns></returns>
	int LWAnsiString_Length(LWAnsiString* str);
	/// <summary>
	/// Wipe the buffer to zero. keep it allocated and null terminate it.
	/// </summary>
	/// <param name="str">strign to do</param>
	/// <returns></returns>
	void LWAnsiString_ZeroString(LWAnsiString* str);

	/// <summary>
	/// Adjust str to new size. If new_size is less than current size, it will truncate the string and null terminate it. If more than current size, we realloc and update.
	/// </summary>
	/// <param name="str"></param>
	/// <param name="new_size"></param>
	/// <returns></returns>
	int LWAnsiString_AdjustSize(LWAnsiString* str, int new_size);

	void LWAnsiString_AppendNewLine(LWAnsiString* str);
	/// <summary>
	/// pad string at the right with c, len times
	/// </summary>
	/// <param name="str"></param>
	/// <param name="c"></param>
	/// <param name="len"></param>
	/// <returns></returns>
	/// <remarks>UNIT TEST</remarks>
	LWAnsiString* LWAnsiString_Pad(LWAnsiString* str, const char c, int len);
	
	/// <summary>
	/// Append a string to the end of the LWAnsiString, realloc as needed and null terminate
	/// </summary>
	/// <param name="str">string to append to</param>
	/// <param name="append">c string to read from</param>
	/// <returns>if str is null, returns null, if append is null, returns string unchanged, otherwise reallocs as needed does strcpy and then appends</returns>
	LWAnsiString* LWAnsiString_Append(LWAnsiString* str, const char* append);

	/// <summary>
	/// Duplicate the passed 
	/// </summary>
	/// <param name="str">string to dup</param>
	/// <returns>null on error and duplicate on ok</returns>
	LWAnsiString* LWAnsiString_Duplicate(LWAnsiString* str);



	/// <summary>
	/// Retrive the raw underlying buffer for the string. Note while  the buffer contents can be changed the pointer itself SHOULD NOT BE
	/// </summary>
	/// <param name="str">type to get buffer to</param>
	/// <returns>buffer value or null</returns>
	const char* LWAnsiString_ToCStr(LWAnsiString* str);


	/// <summary>
	/// Compare a string with a char. Uses case sensitivity if Case is true, otherwise case insensitive
	/// </summary>
	/// <param name="a">furst </param>
	/// <param name="b">next</param>
	/// <param name="Case">care matters</param>
	/// <returns>if both are null, returns 0, if a is null, returns -1, if b is null returns 1, otherwise it's stricmp vs strcmp</returns>
	int LWAnsiString_Compare(LWAnsiString* a, const char* b, bool Case);






}


#endif
