// LWAnsiString.cpp : Defines the functions for the static library.

/*
 * This file is part of the Midas project and is designed to be self-contained.
 * It presents a lightweight mechanism for creating and managing ANSI strings using
 * a customizable heap-based memory strategy that works cleanly even on Win95-era systems.
 *
 * The core structure, `LWAnsiString`, holds:
 *   - a pointer to the character data,
 *   - the current string length (excluding null terminator),
 *   - the total allocated size (including null),
 *   - and a pointer to an `AllocationHandler` describing how to allocate, free, and reallocate memory.
 *
 * By default, strings are stored in the defailt Windows GetProcessHeap(). When first creatin a strin
 * with this library a bit of internal setup is done to prep to use said heap.
 * This avoids CRT dependency  and ensures compatibility with older systems.
 *
 * === Custom Allocator Usage ===
 * To use a custom allocator, set up an `AllocationHandler` (see LWAnsiString.h), and assign:
 *   - `CustomFirstAlloc`
 *   - `CustomFree`
 *   - `CustomReAlloc`
 *   - `CustomGetHeap`
 * 
 * These should mimic the behavior of HeapAlloc/HeapFree semantics, as documented in MSDN or other Microsoft API references.
 * After passing a custom handler, the string will use that handler for all memory operations.
 * The handler is copied internally into the LWAnsiString struct, so you do not need to keep your own reference.
 * 
 * 
 * === Notes and Contracts ===
 * 1. `CreateLWAnsiString`, `CreateLWAnsiStringEx`, `LWAnsiString_Duplicate`, and `_DuplicateEx`
 *    all return *owned* pointers. The internal struct is heap-allocated via the provided or on
 *	  the default process heap and must only be freed using `FreeLWAnsiString()`.
 *    - Exception: If `DefaultHandler` or null is passed to the ex, the default handler is embedded as a static,
 *      shared instance and should never be freed manually.
 *
 * 2. Ownership: Once created, the string struct and its buffer are owned by the library.
 *    Do not attempt to free or reallocate them manually�doing so risks corruption.
 *
 * 3. `len` should never be manually modified. It's maintained by the library routines and reflects
 *    the logical length (not including the null terminator) ie  len here is like caching strlen("on a string").
 *
 * 4. `AllocatedSize` reflects the full buffer size, *including* null terminator. This allows
 *    safe appends and internal resizing logic. ie AllocatedSize will typically be len + 1 for a string of length `len`.
 *	  unless resized
 *
 * 5. All mutating routines null-terminate the string after modification. Even buffer-growing helpers
 *    maintain a safe trailing null.
 *
 * 6. `LWAnsiString_ToCStr()` exposes the internal buffer as a `const char*` for read-only usage.
 *    This enables clean interop with C functions while preserving encapsulation. It's perfectly
 *	  fine to just refer to the raw buffer, however if the raw buffer exposure changes, this should still work.
 *
 * 7. The raw `data` pointer may be directly read or written (up to `AllocatedSize`),
 *    but never freed or reassigned externally. Doing so will break internal tracking.
 */

#include "pch.h"
#include "framework.h"
extern "C" {
	HANDLE StringHeap = 0;

	//#define CONST_CAST(type, val) ((type)(uintptr_t)(const void *)(val))

#define TREAT_AS(type, expression) ((type) ((expression)))
#define TREAT_AS_ALLOT(x) TYPE_AS(AllocationHandler*, x)

	void local_memzero(unsigned char* target, size_t size)
	{
		if (target == nullptr || size == 0)
			return; // nothing to do
		union shim {
			DWORD x86;
			ULONGLONG x64;
		} f;
		f.x64 = 0;
	

		while (size > 0)
		{
			if ((size % sizeof(void*)) == 0)
			{
				if (sizeof(void*) == 4)
				{
					(*(DWORD*)target) = f.x86; // zero out the DWORD
				}
				else if (sizeof(void*) == 8)
				{
					(*(ULONGLONG*)target) = f.x64; // zero out the ULONGLONG
				}
				size -= sizeof(void*);
			}
			else
			{
				*target = 0; // zero out the byte
				size--;
			}
		}
	}
		
	AllocationHandler DefaultHandler = { 0 };

	HANDLE WINAPI DefaultMyHeapGet(DWORD Options, SIZE_T Start, SIZE_T Cap)
	{
		return GetProcessHeap(); // fallback to the default heap
	}

	/*
	* why the if not null and not self? Don't want toa ccidently create a loop where we call ourselves until *boom*
	*/
	HANDLE WINAPI DefaultAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes)
	{
		if ((DefaultHandler.CustomFirstAlloc != nullptr) && (DefaultHandler.CustomFirstAlloc != DefaultAlloc))
		{
			return DefaultHandler.CustomFirstAlloc(hHeap, dwFlags, dwBytes);
		}
		return HeapAlloc(hHeap, dwFlags, dwBytes);
	}
	LPVOID WINAPI DefaultReAlloc(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes)
	{
		if ((DefaultHandler.CustomReAlloc != nullptr) && (DefaultHandler.CustomReAlloc != DefaultReAlloc))
		{
			return DefaultHandler.CustomReAlloc(hHeap, dwFlags, lpMem, dwBytes);
		}
		return HeapReAlloc(hHeap, dwFlags, lpMem, dwBytes);
	}

	BOOL WINAPI DefaultFree(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem)
	{
		if ((DefaultHandler.CustomFree != nullptr) && (DefaultHandler.CustomFree != DefaultFree))
		{
			return DefaultHandler.CustomFree(hHeap, dwFlags, lpMem);
		}
		return HeapFree(hHeap, dwFlags, lpMem);
	}


	/// <summary>
	/// The creater lwansistring calls this if the string heap is not set up. This intializes default
	/// </summary>
	void SetupAnsiString()
	{
		{
			if (StringHeap != 0)
			{
				return; // already set up
			}
			StringHeap = GetProcessHeap();
			DefaultHandler.CustomFirstAlloc = DefaultAlloc;
			DefaultHandler.CustomGetHeap = DefaultMyHeapGet;
			DefaultHandler.CustomFree = DefaultFree;
			DefaultHandler.CustomReAlloc = DefaultReAlloc;
		}
	}

	LWAnsiString* LWAnsiString_CreateString(int len)
	{
		return LWAnsiString_CreateStringEx(&DefaultHandler, len);
	}
	LWAnsiString* LWAnsiString_CreateStringEx(AllocationHandler* x, int len)
	{
		if (x == nullptr)
		{
			x = &DefaultHandler;
		}
		if (len < 0)
		{
			return nullptr; // invalid length
		}

		SetupAnsiString();
		auto Ans = (LWAnsiString*)DefaultHandler.CustomFirstAlloc(StringHeap, HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, sizeof(LWAnsiString));
		if (Ans == nullptr)
		{
			return nullptr; // failed to allocate
		}
		else
		{
			Ans->Data = (char*)DefaultHandler.CustomFirstAlloc(StringHeap, HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, len + 1); // +1 for null terminator

			Ans->AllocatedSize = len + 1; // +1 for null terminator
			if (x != &DefaultHandler)
			{
				// if the default handler is NOT passed, we create a copy of it and stash it as  a pointer in the void* thing.
				Ans->AllocatedHandle = x->CustomFirstAlloc(StringHeap, HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, sizeof(AllocationHandler));
				((AllocationHandler*)Ans->AllocatedHandle)->CustomFirstAlloc = x->CustomFirstAlloc;
				((AllocationHandler*)Ans->AllocatedHandle)->CustomGetHeap = x->CustomGetHeap;
				((AllocationHandler*)Ans->AllocatedHandle)->CustomFree = x->CustomFree;
				((AllocationHandler*)Ans->AllocatedHandle)->CustomReAlloc = x->CustomReAlloc;


			}
			else
			{
				Ans->AllocatedHandle = x;
			}
			if (Ans->Data == nullptr)
			{
				DefaultHandler.CustomFree(StringHeap, 0, Ans);
				Ans = nullptr; // failed to allocate data
				return nullptr; // failed to allocate data
			}
			else
			{
				Ans->Length = 0;
				Ans->Data[len] = 0; // null terminate


				return Ans;
			}
		}
	}

	LWAnsiString* OldCreateLWAnsiString(int len)
	{
		SetupAnsiString();
		auto Ans = (LWAnsiString*)HeapAlloc(StringHeap, HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, sizeof(LWAnsiString));
		if (Ans == nullptr)
		{
			return nullptr; // failed to allocate
		}
		else
		{
			Ans->AllocatedHandle = StringHeap;
			Ans->Data = (char*)HeapAlloc(StringHeap, HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, len + 1); // +1 for null terminator

			Ans->AllocatedSize = len + 1; // +1 for null terminator
			if (Ans->Data == nullptr)
			{
				HeapFree(StringHeap, 0, Ans);
				Ans = nullptr; // failed to allocate data
				return nullptr; // failed to allocate data
			}
			else
			{
				Ans->Length = 0;
				Ans->Data[len] = 0; // null terminate
				Ans->AllocatedHandle = StringHeap; // set the allocated handle

				return Ans;
			}
		}
	}

	LWAnsiString* LWAnsiString_CreateFromStringEx(AllocationHandler* x, const char* str)
	{
		if (str == nullptr)
		{
			return nullptr; // null string
		}
		int len = lstrlenA(str);
		LWAnsiString* Ans = LWAnsiString_CreateStringEx(x, len);
		if (Ans != nullptr)
		{
			lstrcpyA(Ans->Data, str); // copy the string
			Ans->Data[len] = 0; // null terminate
			Ans->Length = len;
		}
		return Ans;
	}
	LWAnsiString* LWAnsiString_CreateFromString(const char* str)
	{
		return LWAnsiString_CreateFromStringEx(&DefaultHandler, str);
	}

	bool LWAnsiString_FreeString(LWAnsiString* str)
	{
		bool StrFree, StructFree, AllotFree;
		StructFree = StrFree = AllotFree = false; // init to false
		if (str == nullptr)
		{
			return false; // nothing to free
		}
		else
		{
			if (str->AllocatedHandle == 0)
			{
				return false; // WE DON'T KNOW HOW TO FREE THIS hense we can't
			}
			else
			{
				// first free the string. Then free the buffer.
				if (str->Data != nullptr)
				{
					StrFree = ((AllocationHandler*)(str->AllocatedHandle))->CustomFree(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), 0, str->Data); // free the data
					str->Data = nullptr; // set to null for autocomplete practices. Honestly with the str being free, it doesn't matter
				}
				else
				{
					StrFree = true; // no data to free, so we consider it freed
				}


				if ((AllocationHandler*)(str->AllocatedHandle) != &DefaultHandler)
				{
					AllotFree = ((AllocationHandler*)(str->AllocatedHandle))->CustomFree(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), 0, str->AllocatedHandle); // free the structure itself
				}
				else
				{
					// the default handler is STATIC AND GLOBAL TO THE FILE DON"T FREE IT
					AllotFree = true;
				}

				// finally free the struct
				StructFree = ((AllocationHandler*)(str->AllocatedHandle))->CustomFree(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), 0, str); // free the structure itself

				if (!StrFree || !StructFree || !AllotFree)
				{
					return false; // failed to free either the data or the structure or the handler
				}
				return true;
			}
		}
	}


	bool OldFreeLWAnsiString(LWAnsiString* str)
	{
		bool StrFree, StructFree;
		StructFree = StrFree = false; // init to false
		if (str == nullptr)
		{
			return false; // nothing to free
		}
		else
		{
			if (str->AllocatedHandle == 0)
			{
				return false; // WE DON'T KNOW HOW TO FREE THIS
			}
			else
			{
				// first free the string. Then free the buffer.
				if (str->Data != nullptr)
				{
					StrFree = HeapFree(str->AllocatedHandle, 0, str->Data); // free the data
					str->Data = nullptr; // set to null for autocomplete practices. Honestly with the str being free, it doesn't matter
				}
				else
				{
					StrFree = true; // no data to free, so we consider it freed
				}

				StructFree = HeapFree(str->AllocatedHandle, 0, str); // free the structure itself
				if (!StrFree || !StructFree)
				{
					return false; // failed to free either the data or the structure
				}
				return true;
			}
		}
	}


	int LWAnsiString_Length(LWAnsiString* str)
	{
		if (str == nullptr)
			return 0; // null string
		return str->Length; // return the length
	}

	void LWAnsiString_ClampNull(LWAnsiString* str)
	{
		if (str && str->Data)
			str->Data[str->Length] = 0;
	}
	/// <summary>
	/// Wipe the buffer to zero. keep it allocated and null terminate it.
	/// </summary>
	/// <param name="str"></param>
	/// <returns></returns>
	void LWAnsiString_ZeroString(LWAnsiString* str)
	{
		if ((str == nullptr) || (str->Data == nullptr) || (str->AllocatedSize <= 0))
			return; // null string or null data or invalid size

		if (str->AllocatedSize % sizeof(void*) == 0)
		{
			// what we're going is are we allocated a chunjk of data divisible by 4 or 8,  we fill in by that value
			union shim {
				DWORD x86;
				ULONGLONG x64;
			} f;
			f.x64 = 0;
			char* step = str->Data;

			for (int i = 0; i < str->AllocatedSize; i += sizeof(void*))
			{
				if (sizeof(void*) == 8)
				{
					*(ULONGLONG*)(step + i) = f.x64; // zero out the buffer
				}
				else
				{
					*(DWORD*)(step + i) = f.x86; // zero out the buffer
				}
			}
		}
		else
			for (int i = 0; i < str->AllocatedSize; i++)
			{
				str->Data[i] = 0; // zero out the buffer
			}

		str->Length = 0;
	}

	int LWAnsiString_AdjustSize(LWAnsiString* str, int new_size)
	{
		if (str == nullptr)
			return 0; // null string
		if (new_size <= 0)
			return str->Length; // no change if size is less than or equal to 0
		if (new_size > str->AllocatedSize)
		{
			char* newPtr = (char*)((AllocationHandler*)(str->AllocatedHandle))->CustomReAlloc(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, str->Data, new_size + 1); // +1 for null terminator
			if (newPtr == nullptr)
			{
				return -1; // failed to reallocate
			}
			else
			{
				str->Data = newPtr; // set the new data pointer
				str->AllocatedSize = new_size + 1; // update the allocated size
				str->Data[str->AllocatedSize - 1] = 0; // null terminate
				return new_size; // return the current length
			}
		}
		else
		{
			LWAnsiString_ClampNull(str); // ensure the string is null terminated
		}
		return str->Length; // no change if size is less than or equal to allocated size
	}
	
	void LWAnsiString_AppendNewLine(LWAnsiString* str)
	{
		LWAnsiString_Append(str, "\r\n"); // append a new line
	}
	LWAnsiString* LWAnsiString_Pad(LWAnsiString* str, const char c, int len)
	{
		if (str == nullptr)
			return nullptr; // null string
		if (len <= 0)
			return str; // no change if size is less than or equal to 0
		if (len + str->Length > str->AllocatedSize)
		{
			LWAnsiString_Reserve(str, len + str->Length); // ensure we have enough space
		}
		if (str->Length + len > str->AllocatedSize)
		{
			return nullptr; // not enough space to pad
		}
		for (int i = str->Length; i < str->Length + len; i++)
		{
			str->Data[i] = c; // pad the string with the character
		}
		str->Length += len; // update the length
		LWAnsiString_ClampNull(str); // ensure the string is null terminated
		return str; // return the updated string
	}
	LWAnsiString* LWAnsiString_Append(LWAnsiString* str, const char* append)
	{
		if (str == nullptr)
			return str;
		if (append == nullptr)
			return str; // nothing to append
		if (str->AllocatedHandle == 0)
			return nullptr; // WE CAN'T CAUSE there's no table of allocator routines
							// TODO: Add unit test to test for this.
		int append_len = lstrlenA(append);
		if (append_len == 0)
			return str; // nothing to append
		int new_size = str->AllocatedSize + append_len;
		if (new_size > str->AllocatedSize)
		{
			LWAnsiString_ClampNull(str);
			//new_size++; // +1 for null terminator 
			// reason above is commented out is we're assuming the original is null term
			char* newPtr = (char*)((AllocationHandler*)(str->AllocatedHandle))->CustomReAlloc(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, str->Data, new_size);
			if (newPtr == nullptr)
			{
				return nullptr; // failed to reallocate
			}
			else
			{
				str->Data = newPtr; // set the new data pointer
				str->Data[str->Length] = 0; // null terminate the existing string 
				str->Length += lstrlenA (append); // update the length
				str->Data[str->Length] = 0; // null terminate the new length on the string we requested
				lstrcatA(str->Data, append); // append the string
				str->Data[str->Length] = 0; // null terminate
				str->AllocatedSize = new_size; // update the allocated size
				return str; // return the updated string	
			}
		}
		else
		{
			lstrcatA(str->Data, append); // append the string
			str->Length += append_len; // update the length
			str->Data[str->Length] = 0; // null terminate
			for (int i = str->Length; i < str->AllocatedSize; i++)
			{
				str->Data[i] = 0; // zero out the rest of the buffer
			}
			return str; // return the updated string
		}
	}


	LWAnsiString* LWAnsiString_Reserve(LWAnsiString* str, int new_size)
	{
		if (str == nullptr)
			return nullptr; // null string
		if (new_size <= 0)
			return str; // no change if size is less than or equal to 0
		if (new_size > str->AllocatedSize)
		{
			char* newPtr = (char*)((AllocationHandler*)(str->AllocatedHandle))->CustomReAlloc(((AllocationHandler*)(str->AllocatedHandle))->CustomGetHeap(0, 0, 0), HEAP_GENERATE_EXCEPTIONS | HEAP_ZERO_MEMORY, str->Data, new_size + 1); // +1 for null terminator
			if (newPtr == nullptr)
			{
				return nullptr; // failed to reallocate
			}
			else
			{
				str->Data = newPtr; // set the new data pointer
				str->AllocatedSize = new_size + 1; // update the allocated size
				str->Data[str->AllocatedSize - 1] = 0; // null terminate
				local_memzero((unsigned char*)str->Data+ str->Length, str->AllocatedSize - 1 - str->Length); // zero out the rest of the buffer
				str->Data[str->Length] = 0; // ensure the string is null terminated
				return str; // return the current string
			}
		}
		return str; // no change if size is less than or equal to allocated size
	}

	/// <summary>
	/// Duplicate the passed string
	/// </summary>
	/// <param name="str">string to dup</param>
	/// <returns>null on error and duplicate on ok</returns>
	LWAnsiString* LWAnsiString_Duplicate(LWAnsiString* str)
	{
		return LWAnsiString_CreateFromString(LWAnsiString_ToCStr(str));
	}

	LWAnsiString* LWAnsiString_DuplicateEx(AllocationHandler* x, LWAnsiString* str)
	{
		return LWAnsiString_CreateFromStringEx(x, LWAnsiString_ToCStr(str));
	}

	/// <summary>
	/// Retrive the raw underlying buffer for the string. Note while  the buffer contents can be changed the pointer itself SHOULD NOT BE
	/// </summary>
	/// <param name="str">type to get buffer to</param>
	/// <returns>buffer value or null</returns>
	const char* LWAnsiString_ToCStr(LWAnsiString* str)
	{
		if (str == nullptr)
		{
			return nullptr; // null string
		}
		return str->Data; // return the data
	}


	int LWAnsiString_Compare(LWAnsiString* a, const char* b, bool Case)
	{
		if (a == nullptr && b == nullptr)
		{
			return 0;
		}
		if (a == nullptr && b != nullptr)
		{
			return -1;
		}
		if (a != nullptr && b == nullptr)
		{
			return 1;
		}
		if (Case)
		{
			return lstrcmpA(a->Data, b); // case sensitive
		}
		else
		{
			return lstrcmpiA(a->Data, b); // case insensitive
		}
	}


}


