#include <Windows.h>
#include "stdpipe.h"

