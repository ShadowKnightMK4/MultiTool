

#include "common.h"

/*
* the common.h file is a common include for all the files in the project. we're doing that stdafx.h thing but with this
*/