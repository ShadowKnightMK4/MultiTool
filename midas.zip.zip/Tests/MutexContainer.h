	#pragma once

extern void BeginToolCritSection();

extern void EndToolCritSection();
